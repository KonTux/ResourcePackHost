---
name: Suggestion
about: Suggest additional support for / changes to Unity.
title: "Suggestion"
labels: suggestion
assignees: ''

---

**Suggestion**
_Tell us what you'd like to see in Unity. (Example: More log variants.)_
